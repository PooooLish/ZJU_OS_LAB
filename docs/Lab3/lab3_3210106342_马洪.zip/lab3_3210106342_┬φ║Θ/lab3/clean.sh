find . -name "*.o" -type f -delete
rm vmlinux