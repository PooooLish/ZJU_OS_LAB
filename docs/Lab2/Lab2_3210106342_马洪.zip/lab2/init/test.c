#include "printk.h"
#include "defs.h"

// Please do not modify

void test() {
    printk("idle process is running!\n");
    while(1) {}
}
